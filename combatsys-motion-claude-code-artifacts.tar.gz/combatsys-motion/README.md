# CombatSys Motion Analysis Platform

Camera-only motion analysis for breathing, gait, posture, and combat sports technique.

Built with **ClojureScript**, **Reagent**, **re-frame**, and **Electron**.

## Philosophy

This project embodies three engineering approaches:

- **Rich Hickey**: Functional core with immutable data, pure functions, and composability
- **John Carmack**: Pragmatic performance optimization on critical paths
- **Paul Graham**: Continuous working prototypes with rapid iteration

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│           IMPERATIVE SHELL (The "Game Loop")            │
│  • Camera I/O, GPU dispatch, UI events, file system     │
│  • Centralized state atom (re-frame style)              │
├─────────────────────────────────────────────────────────┤
│           FUNCTIONAL CORE (The "Logic Engine")          │
│  • Pure functions: data → data                          │
│  • EDN IR transformations                               │
│  • Analytics, metrics, insights                         │
└─────────────────────────────────────────────────────────┘
```

## Current Status: LOD 0

**LOD 0** = Foundational scaffolding with mock data. Everything is connected end-to-end, but using stubs.

✅ **What works now:**
- Complete EDN schema for sessions, frames, poses, and analysis
- Mock data generators for breathing and posture sessions
- Stub analyzers (breathing, posture) that return hardcoded results
- Full re-frame state management
- Reagent UI with timeline, skeleton overlay, and metrics panels
- Electron desktop app shell

🚧 **Next (LOD 1):**
- Real camera capture via getUserMedia
- MediaPipe pose estimation integration
- Real-time skeleton overlay
- Session recording to disk

## Installation

### Prerequisites

- **Node.js** v18+ and npm
- **Java** 11+ (for ClojureScript compiler)

### Setup

```bash
# Install npm dependencies
npm install

# Install shadow-cljs globally (optional but recommended)
npm install -g shadow-cljs
```

## Development Workflow

### Quick Start

```bash
# Terminal 1: Watch and compile ClojureScript
npx shadow-cljs watch main renderer

# Terminal 2: Start Electron app
npm start
```

The app will open in an Electron window. Changes to ClojureScript code will hot-reload automatically.

### REPL-Driven Development

```bash
# Start shadow-cljs with REPL
npx shadow-cljs watch main renderer

# In another terminal, connect to REPL
npx shadow-cljs cljs-repl renderer
```

Now you can interact with the running app from your REPL:

```clojure
;; Evaluate in REPL
(require '[combatsys.renderer.state :as state])
(require '[re-frame.core :as rf])

;; Inspect current state
@re-frame.db/app-db

;; Dispatch events
(rf/dispatch [::state/load-demo-session])

;; Subscribe to values
@(rf/subscribe [::state/current-session])
```

## Project Structure

```
combatsys-motion/
├── src/
│   ├── shared/              # Pure ClojureScript (platform-agnostic)
│   │   ├── schema.cljs     # EDN schema definitions
│   │   ├── mocks.cljs      # Mock data generators
│   │   ├── breathing.cljs  # Breathing analyzer (stub)
│   │   └── posture.cljs    # Posture analyzer (stub)
│   │
│   ├── renderer/           # Electron renderer process (browser)
│   │   ├── core.cljs      # Entry point
│   │   ├── state.cljs     # re-frame state management
│   │   └── views.cljs     # Reagent UI components
│   │
│   └── main/               # Electron main process (Node.js)
│       └── core.cljs      # App lifecycle, window management
│
├── resources/
│   └── public/
│       └── index.html      # HTML entry point
│
├── shadow-cljs.edn         # ClojureScript build config
├── package.json            # npm dependencies
└── README.md
```

## Testing the LOD 0 Build

1. Click **"Load Demo Session"** button
2. You should see:
   - A 60-second mock breathing session loaded
   - Skeleton canvas (empty for now, will show stick figure in LOD 1)
   - Timeline scrubber (drag to navigate through frames)
   - Breathing metrics: 22 bpm, depth score, fatigue windows
   - Posture metrics: forward head, shoulder imbalance
   - Insights with recommendations

This demonstrates the entire data flow: mock data → analyzers → UI display.

## Development Roadmap

### ✅ LOD 0: Foundation (Complete - Day 1)
- EDN schema definitions
- Mock data generators
- Stub analyzers
- Basic UI with timeline and metrics

### 🚧 LOD 1: Real Camera (Days 2-4)
- Camera capture via getUserMedia
- MediaPipe pose estimation
- Real-time skeleton overlay
- Session recording

### 🔮 LOD 2: Breathing Analysis (Days 5-7)
- Real torso motion extraction
- FFT-based breathing rate detection
- Fatigue window detection
- Coaching insights

### 🔮 LOD 3: Eulerian Magnification (Days 8-10)
- WebGPU compute shaders
- Motion magnification for breathing visualization
- ROI selection and rendering

### 🔮 LOD 4: Posture Analysis (Days 11-13)
- Real geometric posture assessment
- Forward head, shoulder imbalance detection
- Spine alignment analysis

### 🔮 LOD 5: Personalization (Days 14-16)
- User calibration flow
- Learned baselines and thresholds
- Personalized feedback

### 🔮 LOD 6: Multi-Session (Days 17-18)
- Session comparison
- Trend analysis
- Historical insights

## Key Concepts

### EDN IR (Intermediate Representation)

All data in the system is represented as **immutable EDN maps**. This is the "assembly language" of motion analysis.

Example session:

```clojure
{:session/id #uuid "..."
 :session/timeline
 [{:frame/index 0
   :frame/timestamp-ms 0
   :frame/pose {:pose/landmarks [...] :pose/confidence 0.94}
   :frame/derived {:angles {...} :velocities {...}}
   :frame/events []}
  ...]
 :session/analysis
 {:breathing {:rate-bpm 22 :fatigue-windows [...]}
  :posture {:head-forward-cm 4.2 ...}}}
```

### Pure Functional Core

All analysis is done via **pure functions** that transform data:

```clojure
(defn analyze [session]
  (-> session
      breathing/analyze    ;; session → session with breathing analysis
      posture/analyze))    ;; session → session with posture analysis
```

This makes the code:
- ✅ Testable without mocks
- ✅ Composable (easy to add new analyzers)
- ✅ Debuggable (inspect data at any stage)

### Imperative Shell

Side effects (camera, file I/O, GPU) are isolated to:
- Electron main process (`src/main/`)
- Event handlers in re-frame (`src/renderer/state.cljs`)

The functional core never touches I/O.

## Design Principles

### 1. Data Orientation (Hickey)
- Everything is data (EDN maps and vectors)
- Functions transform data immutably
- No hidden state or side effects in core logic

### 2. Observability (Brett Victor)
- Every metric shows its reasoning
- Timeline is scrubable and inspectable
- Insights explain "why", not just "what"

### 3. Iteration Speed (Graham)
- Hot reload during development (<2s feedback)
- REPL-driven development
- Always have a working prototype

### 4. Performance (Carmack)
- Profile before optimizing
- GPU for heavy lifting (WebGPU shaders)
- Critical path awareness (30fps target for real-time)

## FAQ

**Q: Why ClojureScript instead of Python?**

A: We want:
- Pure functional core (easier in Clojure)
- Desktop app with hot reload (Electron + ClojureScript)
- Composable data transformations (EDN + pure functions)
- Fast iteration (REPL-driven development)

Python will be used for heavy ML/CV tasks (MediaPipe, Eulerian magnification) but will emit EDN-compatible JSON that ClojureScript consumes.

**Q: Why Electron instead of web browser?**

A: Desktop app allows:
- Native camera access with better performance
- File system for session storage
- Future GPU acceleration via native modules
- Better UX for long-running analysis

**Q: Can I use this without a camera?**

A: Yes! Load the demo session (`Load Demo Session` button) to explore the UI and analysis without hardware.

## Troubleshooting

**Error: "Java not found"**
- Install Java 11+ (required for ClojureScript compilation)

**Error: "Cannot find module 'electron'"**
- Run `npm install` to install dependencies

**App window is blank**
- Check Terminal 1 for compilation errors
- Wait for "Build completed" message before starting Electron

**Hot reload not working**
- Make sure shadow-cljs watch is running
- Check browser console for errors

## License

MIT

---

**Built with ❤️ and ClojureScript**
