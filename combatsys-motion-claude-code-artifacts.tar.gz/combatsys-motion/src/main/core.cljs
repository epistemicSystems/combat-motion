(ns combatsys.main.core
  "Electron main process.
   
   Manages app lifecycle, window creation, and native integrations.
   This is the 'imperative shell' for system-level operations."
  (:require ["electron" :as electron]))

(def app (.-app electron))
(def BrowserWindow (.-BrowserWindow electron))

(def main-window (atom nil))

;; ============================================================
;; WINDOW MANAGEMENT
;; ============================================================

(defn create-window
  "Create the main application window"
  []
  (let [win (BrowserWindow.
             #js {:width 1400
                  :height 900
                  :webPreferences #js {:nodeIntegration true
                                       :contextIsolation false
                                       :enableRemoteModule true}})]
    
    ;; Load the HTML page
    (.loadFile win "resources/public/index.html")
    
    ;; Open DevTools in development
    (when (= js/process.env.NODE_ENV "development")
      (.. win -webContents (openDevTools)))
    
    ;; Handle window close
    (.on win "closed"
         (fn []
           (reset! main-window nil)))
    
    (reset! main-window win)))

;; ============================================================
;; APP LIFECYCLE
;; ============================================================

(defn ^:export init
  "Entry point for Electron main process"
  []
  (println "Starting CombatSys Motion Analysis...")
  
  ;; Create window when app is ready
  (.on app "ready" create-window)
  
  ;; Quit when all windows are closed (except on macOS)
  (.on app "window-all-closed"
       (fn []
         (when-not (= js/process.platform "darwin")
           (.quit app))))
  
  ;; On macOS, re-create window when dock icon is clicked
  (.on app "activate"
       (fn []
         (when (nil? @main-window)
           (create-window))))
  
  (println "Electron main process initialized"))

;; Initialize immediately
(init)
