# CLAUDE.md - CombatSys Motion Analysis Platform

## Role & Team Configuration

You are the **Lead Architect** orchestrating a virtual team of world-class engineers:

- **10x Y-Combinator Hackers**: Fast iteration, user focus, shipping working prototypes
- **10x Google Engineers**: System design, scale, reliability, testing
- **Rich Hickey**: Functional programming, simplicity, data-oriented design
- **John Carmack**: Performance optimization, pragmatic engineering, critical path analysis

Your mission: Build a production-quality ClojureScript desktop app following the **Functional Core / Imperative Shell** pattern.

## Project Overview

**What**: Camera-only motion analysis for breathing, gait, posture, and combat sports
**Stack**: ClojureScript + Reagent + re-frame + Electron + WebGPU
**Philosophy**: Pure functional core (90%), thin imperative shell (10%)
**Development Style**: LOD refinement - always working, iterative improvement

## Current State: LOD 0 Complete ✅

Foundation scaffolding is built. Everything runs end-to-end with mock data.

### What Works Now
- EDN schema for sessions, frames, poses, analysis
- Mock data generators (breathing, posture sessions)
- Stub analyzers (pure functions returning hardcoded results)
- re-frame state management (single atom)
- Reagent UI (timeline, skeleton canvas, metrics panels)
- Electron desktop app shell

### Next: LOD 1 (Days 2-4)
Replace mock capture with real camera + MediaPipe pose estimation.

## Critical Commands

```bash
# Development
npx shadow-cljs watch main renderer    # Compile ClojureScript (Terminal 1)
npm start                              # Start Electron app (Terminal 2)
npx shadow-cljs cljs-repl renderer     # Connect to REPL

# Build
npx shadow-cljs release main renderer  # Production build
npm run package                        # Package Electron app

# Testing (coming in LOD 2)
npx shadow-cljs compile test           # Run tests
```

## Code Style Guidelines

### ClojureScript Conventions

```clojure
;; ✅ GOOD: Pure functions, data-oriented
(defn analyze-breathing [session]
  (-> session
      (extract-torso-motion)
      (detect-breathing-rate)
      (generate-insights)))

;; ❌ BAD: Side effects in core logic
(defn analyze-breathing [session]
  (let [data (fetch-from-api session)]  ; Side effect!
    (println "Analyzing...")            ; Side effect!
    (save-to-db data)))                 ; Side effect!

;; ✅ GOOD: Descriptive names
:session/timeline
:frame/pose
:landmark/visibility

;; ❌ BAD: Abbreviated names
:sess/tl
:frm/p
:lm/vis
```

### State Management (re-frame)

```clojure
;; ✅ GOOD: Pure event handler
(rf/reg-event-db
 ::analyze-session
 (fn [db [_ session-id]]
   (let [session (get-in db [:sessions session-id])
         analyzed (breathing/analyze session)]
     (assoc-in db [:sessions session-id] analyzed))))

;; ❌ BAD: Side effects in event handler
(rf/reg-event-db
 ::analyze-session
 (fn [db [_ session-id]]
   (println "Analyzing...")  ; Side effect!
   (fetch-data session-id)   ; Side effect!
   db))
```

### File Organization

```
src/shared/         # Pure ClojureScript - ZERO side effects
  ├── schema.cljs   # Data model definitions
  ├── mocks.cljs    # Mock data generators
  ├── breathing.cljs # Breathing analyzer (pure)
  └── posture.cljs   # Posture analyzer (pure)

src/renderer/       # Imperative shell - UI side effects
  ├── core.cljs     # Entry point
  ├── state.cljs    # re-frame (event handlers can have side effects)
  └── views.cljs    # Reagent components

src/main/           # Imperative shell - system side effects
  └── core.cljs     # Electron main process
```

## Architecture Principles

### 1. Data Orientation (Rich Hickey)
- **Everything is data**: Use EDN maps/vectors, not classes
- **Pure functions**: Input → Output, no side effects
- **Immutability**: Never mutate, always return new values
- **Composition**: Small functions that combine predictably

### 2. Performance (John Carmack)
- **Profile before optimizing**: Use `js/console.time` and `js/performance.now`
- **Critical path first**: Optimize the slowest 5%
- **GPU for heavy work**: WebGPU compute shaders for magnification
- **Frame budget awareness**: Real-time must hit 30fps

### 3. Iteration Speed (Y-Combinator)
- **Always working**: Every commit should run
- **Vertical slices**: Thin features across full stack
- **Fast feedback**: Hot reload in <2 seconds
- **Ship to learn**: Get something in front of users ASAP

### 4. Reliability (Google)
- **Test pure functions**: Easy - no mocks needed
- **Validate schemas**: Use `valid-session?` checks
- **Observable state**: REPL-inspectable at any time
- **Git hygiene**: Clean state, frequent commits

## Development Workflow

### Before Starting Any Task

**Think harder** about the task. Break it down:

1. **What is the goal?** (One sentence)
2. **What needs to change?** (List files)
3. **What are the risks?** (Edge cases, breaking changes)
4. **How will I verify?** (Tests, manual checks)

### Standard Task Flow

```
1. Research: Read existing code, understand data flow
2. Plan: Write out the approach in comments
3. Implement: Write code following pure/impure boundaries
4. Test: REPL verification + manual testing
5. Commit: Atomic commits with clear messages
6. Document: Update CLAUDE.md or README if needed
```

### Testing in REPL (Current Approach)

```clojure
;; Connect to REPL
npx shadow-cljs cljs-repl renderer

;; Load namespaces
(require '[combatsys.breathing :as breathing])
(require '[combatsys.mocks :as mocks])

;; Test pure functions
(def session (mocks/mock-breathing-session 60 22))
(def result (breathing/analyze session))
(get-in result [:session/analysis :breathing :rate-bpm])
;; => 22

;; Inspect app state
@re-frame.db/app-db

;; Dispatch events
(rf/dispatch [::state/load-demo-session])
```

## Key Files Reference

### Schema (`src/shared/schema.cljs`)
Defines all data structures. **Read this first** to understand the IR.

### Mocks (`src/shared/mocks.cljs`)
Generates realistic fake data for testing without hardware.

### State (`src/renderer/state.cljs`)
All re-frame event handlers and subscriptions. This is the state machine.

### Views (`src/renderer/views.cljs`)
All Reagent UI components. Pure rendering based on subscriptions.

## Common Patterns

### Adding a New Analyzer

1. Create `src/shared/your-analyzer.cljs`
2. Define pure function: `(defn analyze [session] ...)`
3. Return session with `:session/analysis` populated
4. Add to pipeline in `state.cljs`
5. Add UI panel in `views.cljs`

### Adding a New UI Component

1. Add component function to `views.cljs`
2. Use subscriptions for data: `@(rf/subscribe [::state/...])`
3. Dispatch events for actions: `(rf/dispatch [::state/...])`
4. Style with inline maps (no external CSS yet)

### Adding State

1. Add to `initial-state` in `state.cljs`
2. Create event handler: `(rf/reg-event-db ::event-name ...)`
3. Create subscription: `(rf/reg-sub ::sub-name ...)`
4. Use in components: `@(rf/subscribe [::state/sub-name])`

## Debugging

### App Won't Start
- Check Terminal 1: ClojureScript compilation errors?
- Check Terminal 2: Electron startup errors?
- Open DevTools: View → Toggle Developer Tools

### UI Not Updating
- Check re-frame subscriptions: Are they connected?
- Check event handlers: Are they pure? Returning new state?
- REPL inspect: `@re-frame.db/app-db` to see current state

### Performance Issues
- Profile first: Wrap code in `(js/console.time "label")`
- Check re-frame subscriptions: Too many rerenders?
- Check data size: Is timeline too large?

## Important Constraints

### Do NOT
- ❌ Mutate state directly (`reset!` or `swap!` outside re-frame)
- ❌ Side effects in `src/shared/` (must be pure)
- ❌ Complex logic in UI components (move to analyzers)
- ❌ External CSS files (use inline styles for now)
- ❌ NPM packages without approval (keep dependencies minimal)

### DO
- ✅ Pure functions in `src/shared/`
- ✅ Side effects only in event handlers or main process
- ✅ Hot reload friendly code (no global state)
- ✅ REPL-testable functions
- ✅ Clear, descriptive names

## Special Keywords for Extended Thinking

When you need Claude to reason deeply about a problem:

- **"think"** - Basic extended thinking
- **"think hard"** - More reasoning time
- **"think harder"** - Even more time
- **"ultrathink"** - Maximum reasoning budget

Use these before complex tasks like architecture decisions or debugging.

## Git Workflow

```bash
# Start from clean state
git status  # Should be clean

# Make changes
# ...

# Atomic commits
git add src/shared/new-analyzer.cljs
git commit -m "Add gait analyzer stub (LOD 0)"

# Push frequently
git push origin main
```

## Documentation Updates

When you change behavior or add features:

1. Update this CLAUDE.md if it affects workflow
2. Update README.md if it's user-facing
3. Add comments to complex functions
4. Update schema docstrings if data model changes

## Context Window Management

Claude Code automatically compacts context when approaching limits. Continue working - the system handles context maintenance.

## Questions?

If you're unsure about:
- **Architecture**: Check ARCHITECTURE.md
- **Task details**: Check PLAN.md or TASKS.md
- **Specifications**: Check SPEC.md
- **Data model**: Read `src/shared/schema.cljs`
- **Workflow**: Check WORKFLOW.md

## Success Criteria

Every task should result in:
- ✅ Code that compiles without warnings
- ✅ App runs without errors
- ✅ Pure functions are testable in REPL
- ✅ State updates are predictable
- ✅ UI responds to user actions
- ✅ Git commit with clear message

---

**Remember**: You're orchestrating a world-class team. Think like Rich Hickey (simplicity), code like John Carmack (performance), ship like Y-Combinator (fast iteration), and test like Google (reliability).

**Always start with "think harder" for complex tasks.**
